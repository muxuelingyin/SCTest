package com.jeremy.lychee.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.jeremy.lychee.R;
import com.jeremy.lychee.unit.SCHelper;


/**
* 描述：时间和金钱填写入口
* @author zhaochangqing
* @time 2023/4/24
*/
public class MainActivity extends AppCompatActivity {
    private EditText tv_amount, tv_time;
    private TextView tv_amount_label, tv_time_label, tv_submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView(){
        tv_amount = findViewById(R.id.tv_amount);
        tv_time = findViewById(R.id.tv_time);
        tv_amount_label = findViewById(R.id.tv_amount_label);
        tv_time_label = findViewById(R.id.tv_time_label);
        tv_submit = findViewById(R.id.tv_submit);
        //设置金钱输入过滤器
        tv_amount.setFilters(new InputFilter[]{new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                if(source.equals(".") && dest.toString().length() == 0){
                    return "0.";
                }
                if(dest.toString().contains(".")){
                    int index = dest.toString().indexOf(".");
                    int length = dest.toString().substring(index).length();
                    if(length == 3){
                        return "";
                    }
                }
                return null;
            }
        }});
        tv_amount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String money = s.toString();
                if(SCHelper.isMoneyRight(money)){
                    String text = SCHelper.moneyFormat(Double.parseDouble(money));
                    tv_amount_label.setText(text);
                }
            }
        });

        tv_time.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                try {
                    long time = Long.parseLong(s.toString());
                    String newTime = SCHelper.second2Time(time);
                    tv_time_label.setText(newTime);
                }catch (Exception e){
                    tv_time_label.setText("please enter right time！");
                }
            }
        });

        tv_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SCHelper.calculateResult(tv_amount.getText().toString(), tv_time.getText().toString());
                Intent intent = new Intent(MainActivity.this, ResultActivity.class);
                startActivity(intent);
            }
        });
    }

}