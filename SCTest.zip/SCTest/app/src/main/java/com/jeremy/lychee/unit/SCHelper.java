package com.jeremy.lychee.unit;

import android.text.TextUtils;

import java.math.RoundingMode;
import java.text.DecimalFormat;

/**
 * 描述：包含金钱和时间格式化的工具
 *
 * @author zhaochangqing
 * @time 2023/4/24
 */
public class SCHelper {

    static String Money = "(^[1-9](\\d+)?(\\.\\d{1,2})?$)|(^0$)|(^\\d\\.\\d{1,2}$)";

    public static boolean isMoneyRight(String text) {
        //输入不能为空
        if (TextUtils.isEmpty(text)) {
            return false;
        }

        //格式是否符合金额
        if (!text.matches(Money)) {
            return false;
        }

        //金额不能小于等于 0
        if (Double.parseDouble(text) <= 0) {
            return false;
        }

        return true;
    }

    /**
     * 格式化时间为字符格式
     *
     * @param money
     */
    public static String moneyFormat(double money) {
        DecimalFormat df = new DecimalFormat("#,###.##"); //将数据转换成以3位逗号隔开的字符串，并保留两位小数
        df.setRoundingMode(RoundingMode.FLOOR);//不四舍五入
        String result = df.format(money);
        return result;
    }

    /**
     * 把秒转换为时分秒
     * @param second
     */
    public static String second2Time(Long second) {
        if (second == null || second < 0) {
            return "0S";
        }

        long h = second / 3600;
        long m = (second % 3600) / 60;
        long s = second % 60;
        StringBuilder stringBuilder = new StringBuilder();
        if(h>0){
            stringBuilder.append(h+"h");
        }
        if(m>0){
            stringBuilder.append(m+"m");
        }
        if(s>0){
            stringBuilder.append(s+"s");
        }
        return stringBuilder.toString();

    }

    public static void calculateResult(String money, String time){
        double dMoney = Double.parseDouble(money);
        double dTime = Double.parseDouble(time);
        double result = dMoney * dTime;
        Data.addResult(result);
    }

}
