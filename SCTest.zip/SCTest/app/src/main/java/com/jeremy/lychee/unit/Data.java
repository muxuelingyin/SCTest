package com.jeremy.lychee.unit;

import java.util.ArrayList;
import java.util.List;

/**
* 描述：存储计算结果
* @author zhaochangqing
* @time 2023/4/24
*/
public class Data {

   public static List<Double> list = new ArrayList<>();

   public static void addResult(double result){
      list.add(result);
   }

   public static void clear(){
      if(list != null) {
         list.clear();
         list = null;
      }
   }

}
