package com.jeremy.lychee.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.jeremy.lychee.R;
import com.jeremy.lychee.unit.Data;

public class ResultAdapter extends RecyclerView.Adapter<ResultAdapter.MyViewHolder> {

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_result_adapter, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        holder.tvResult = view.findViewById(R.id.tv_result);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.tvResult.setText(Data.list.get(position).toString());
    }

    @Override
    public int getItemCount() {
        if(Data.list == null){
            return 0;
        }
        return Data.list.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView tvResult;
        public MyViewHolder(View itemView) {
            super(itemView);
            tvResult = itemView.findViewById(R.id.tv_result);
        }
    }

}
