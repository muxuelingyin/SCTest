package com.jeremy.lychee.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.jeremy.lychee.R;
import com.jeremy.lychee.adapter.ResultAdapter;

/**
* 描述：计算的结果
* @author zhaochangqing
* @time 2023/4/24
*/
public class ResultActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ResultAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        initView();
    }

    private void initView(){
        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(ResultActivity.this));
        adapter = new ResultAdapter();
        recyclerView.setAdapter(adapter);
    }

}